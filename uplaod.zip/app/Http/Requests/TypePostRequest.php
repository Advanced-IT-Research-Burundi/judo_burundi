<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TypePostRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'nom' => 'required|string|max:255|unique:type_posts,nom,' . $this->type_post?->id,
            'description' => 'nullable|string|max:1000',
        ];
    }
}
