<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class GalleryImage extends Model
{
    use HasFactory;

    protected $table = 'gallery_images';
    protected $guarded = [];

    public function competition()
    {
        return $this->belongsTo(Competition::class);
    }
}
